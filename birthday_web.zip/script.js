
document.getElementById("showMessageBtn").addEventListener("click", function() {
    const specialMessage = document.getElementById("specialMessage");
    if (specialMessage.classList.contains("hidden")) {
        specialMessage.classList.remove("hidden");
        this.textContent = "Sembunyikan Pesan Khusus";
    } else {
        specialMessage.classList.add("hidden");
        this.textContent = "Tampilkan Pesan Khusus";
    }
});
